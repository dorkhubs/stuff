﻿=== Royal Elementor Addons Pro ===
Contributors: WP Royal
Tags: page builder, editor, landing page, drag-and-drop, elementor, visual editor, wysiwyg, design, maintenance mode, coming soon, under construction, website builder, landing page builder, front-end builder
Stable tag: 1.3.5
Requires at least: 5.0
Tested up to: 6.1
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Premium extension of Royal Elementor Addons based on the Elementor Page Builder.